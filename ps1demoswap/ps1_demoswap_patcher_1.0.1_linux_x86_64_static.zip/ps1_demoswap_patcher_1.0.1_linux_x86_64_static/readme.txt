# PS1 DemoSwap Patcher
By: [MottZilla](http://www.psxdev.net/forum/memberlist.php?mode=viewprofile&u=867). Ported to other operating systems by [Alex Free](http://www.psxdev.net/forum/memberlist.php?mode=viewprofile&u=6018).

## Summary
This program can:
* Patch various commonly found PS1 demo discs to load TonyHax for perfect backup and import booting. It uses a new single swap trick method for any PS1 console that requires you to have an authentic PS1 demo disc supported by PS1 DemoSwap Patcher, as well as a rip of it. 
* Patch **any** game to load TonyHax prior to loading the main game executable. When you use a swap trick to boot a game patched in this way, all the limitations of any swap trick method go away. You get working CD audio and correct TOC data. You even gain the ability to swap to the next (burned backup) disc in games that span multiple discs without having to do another swap trick.

## Why
I created this program and [MCTOOL](https://alex-free.github.io/ps1demoswap/MCTOOL_v10a.zip) to give someone without access to commonly used tools a way to install and or use TonyHax and FreePSXBoot. No modded PS2 or PC memory card interface required.

With the 'DemoSwap' method you can use an authentic, commonly found demo disc and a patched CD-R of the same demo disc to boot TonyHax. TonyHax then enables you to run an import or CD-R disc. No tricky timing or fast reflexes required, and it works on any PS1 console. In this mode it will replace one of the demo executables in the track 01 bin file of a demo disc rip with TonyHax and by doing a simple disc swap while booted in the demo disc that works on any PS1 console you can load TonyHax. You must have an original authentic demo disc that is supported. It is recommended after starting TonyHax using the DemoSwap method to run [MCTOOL](https://alex-free.github.io/ps1demoswap/MCTOOL_v10a.zip) to install FreePSXBoot + TonyHax onto a memory card.

With the 'TOCPerfect' method you can swap trick a patched CD-R of a backup game/import that will not have any of the downsides that normally come with using a swap trick to play a backup/import. The TOC data is re-read and the drive is unlocked so any patched backup you play with a swap trick will always have perfect audio and the ability to switch from i.e. game disc 1 to game disc 2 mid-game. **This takes the swap trick as a backup method as far as possible. The TOCPerfect method is most useful for consoles with a serial number lower then 592xxx which can use the audio menu swap trick. This swap trick does not involve swapping a moving disc**. The idea was first worked
on by [Alex Free](https://alex-free.github.io/tocperfect/).

## Posts About PS1 DemoSwap Patcher At [psxdev.net](http://psxdev.net/forum)
* [TOCPerfect](http://www.psxdev.net/forum/viewtopic.php?f=66&t=3881)
* [MCTOOL](http://www.psxdev.net/forum/viewtopic.php?f=66&t=3910)

## Downloads

### Version 1.0.1 (3/14/2022)
* [Windows x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_win_x86.zip)
* [Mac OS X](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_mac_os_x.zip) *For PowerPC, 32-bit Intel, and 64-bit Intel Macs running Mac OS X 10.3.9 and up.*
* [Linux x86](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_linux_x86_static.zip) *For modern 32-bit Linux distros (static build).*
* [Linux x86_64](https://alex-free.github.io/ps1demoswap/ps1_demoswap_patcher_1.0.1_linux_x86_64_static.zip) *For modern 64-bit Linux distros (static build).*

### Version 1.0 (2/28/2022)
* [Windows x86](https://alex-free.github.io/ps1demoswap/PS1_DemoSwap_v1.0.zip)

## TOCPerfect Requirements
* PS1 Console (NTSC/U or PAL).
* Any authentic PS1 game.
* A high quality blank CD-R.
* Backup of a ripped game.
* CD burner that can burn at a slow speed (8x or slower recommended).

## TOCPerfect Instructions

TOCPerfect patch the first data track of the game you want to use. The first data track will be named something like 'track 01.bin' in your game rip directory. 

On Windows you can:
* Drag and drop the 'track 01.bin' file into the 'PS1 DemoSwap Patcher.exe', then select the TOCPerfect patch mode.
* Start 'PS1 DemoSwap Patcher.exe'. Select the patch mode to TOCPerfect patch and then select the 'track 01.bin' file in the GUI.
* Run 'PS1 DemoSwap Patcher.exe' from 'cmd.exe' as a CLI program. Sample:
'"PS1 DemoSwap Patcher.exe" -t track01.bin'

On other operating systems you can only use PS1 DemoSwap Patcher as a CLI. Sample:
'ps1demoswap -t track01.bin'

Burn the '.cue' file in your game rip directory after applying the TOCPerfect patch to a blank CD-R. Do a swap trick to boot your burned CD-R. When Tonyhax boots and says 'Swap CD Now', unjam the lid sensor and close the lid without touching the CD-R in the PS1. The game will then load with correct audio, TOC data, and an unlocked drive.

If you have a console with a serial number lower then 592xxx then you can use the audio menu swap trick, which does not involve swapping a moving disc. There are more swap tricks for newer consoles that involve swapping a moving disc, written about at the original [swap trick guide](https://gamefaqs.gamespot.com/ps/916392-playstation/faqs/4708) that could also be used. Alternatively, the DemoSwap method provides an easier single swap method to boot TonyHax on all PS1 consoles.

Audio Menu Swap Trick:
1. Turn on the PS1 console with no game in it. Start the CD player, then place a real psx game in the psx 
console.
2. Press the lid sensor down with something that will keep it pressed down. You could use a molded gum
wrapper. The lid sensor is at the top right of console, it is the circle button that is pressed down by the 
top of the CD drive lid). The real psx game will spin for a few seconds and then stop spinning.
3. Swap the real authentic PS1 game for a burned CD-R and exit the CD player. The burned CD-R will start spinning and
boot.

## DemoSwap Requirements
* PS1 Console (NTSC/U or PAL).
* An authentic supported demo disc (must match your console region).
* 2 high quality blank CD-Rs (one for the patched demo disc, one for your backup or 
[MCTOOL](https://alex-free.github.io/ps1demoswap/MCTOOL_v10a.zip).
* Rip of a supported demo disc.
* CD burner that can burn at a slow speed (8x or slower recommended).

## DemoSwap Patch Instructions
1. Check the DiscLib.txt for the title of the demo disc you have or will obtain. As of this writing all
   Interactive CD Sampler volumes 1 through 11 are supported. More demos can be added, details below.
2. Create a raw ISO image of your demo disc using a tool like ISOBuster.
3. On Windows you can:
* Drag and drop the 'track 01.bin' file into the 'PS1 DemoSwap Patcher.exe', then select the DemoSwap
patch mode.
* Start 'PS1 DemoSwap Patcher.exe'. Select the DemoSwap patch mode and then select the
'track 01.bin' file in the GUI.
* Run 'PS1 DemoSwap Patcher.exe' from 'cmd.exe' as a CLI program. Sample: 
'"PS1 DemoSwap Patcher.exe" -d track01.bin'.

On other operating systems you can only use PS1 DemoSwap Patcher as a CLI. Sample:
'ps1demoswap -d track01.bin'

4. The program will report if patching succeeded or not.
5. Burn the patched disc to a CD-R. You can ignore any ECC/EDC, L-EC, etc. errors reported during
   disc verification. Error correction fields are auto corrected by your burner.
6. Put the original demo disc in your PS1. Using your method of choice you must hold down the lid
   switch so the console will read discs with the lid open. A wooden toothpick can work.
7. Power on the system and consult the 'Per Disc Instruction' section.

## Per Disc Instruction
* All Discs Note - When you remove the original disc you do not need to rush to replace it with the CD-R. I found on my SCPH-7501 when removing the disc the motor and laser will try to read the disc you have removed for a few seconds before giving up. After that you can easily place the CD-R into the console. When you take your next action the CD-R should begin spinning and reading. However if you removed the disc at a time when data was being read the system may lock up. Read the notes below to know when you should be removing the original disc and swapping in the CD-R.

* Vol 1 - Select 'Loaded' demo. While on the screen with Start and Help, swap discs, then start the demo.

* Vol 2 - Load Demo 'Need For Speed'. On 'game mode' menu swap discs. Press Select to exit to main menu.
  Load NBA Shoot Out demo.

* Vol 3 & 3.5 - Load Crash Bandicoot demo. When you control Crash, swap discs. Then Press Select to
  return to main menu. Load 2Xtreme demo.

* Vol 4 - Start Croc demo. Once controlling Croc swap discs. Press Select to exit. Start Parappa demo.

* Vol 5 - Start Crash 2 demo. Once you control Crash, swap discs. Press select to return to menu. Start Parappa demo.
* Vol 6 - Start Crash 2 demo. Once you control Crash, swap discs. Press select to return to menu. Start Bloody Roar.
* Vol 7 - Select Blasto demo. On instruction screen swap discs, then start demo.
* Vol 8 - Select Spyro demo. On instruction screen swap discs, then start demo.
* Vol 9 - Select Crash 3 demo. On instruction screen swap discs, then start demo.
* Vol 10 - Select Contender demo. On instruction screen swap discs, then start demo.
* Vol 11 - Select Ape Escape demo. On instruction screen swap discs, then start demo.
* PSOne Wherever, Whenever, Forever - Select Atlantis demo. On instruction screen swap discs, then start demo.

## Adding more Demo Discs
You can add your own demo disc to DiscLib.txt if your demo is not supported. The format of DiscLib is simple. The first line is a Title of the disc. Recommended you use the name in the Redump set. The second line is the Executable file loaded by SYSTEM.CNF. This is needed to identify each disc. The third line is the name of the demo executable to replace with TonyHax. I usually choose the first demo selected on the disc but you can choose any you wish. The DiscLib.txt should end with three lines of three dots. So add your discs before the ... or just add your discs at the top of the file. 

Make an ISO image of your demo disc that is not supported. Open the SYSTEM.CNF file and find the boot executable. Then find the demo executable you want to replace. Add this information to DiscLib.txt. ISOBuster can help you find all of this information. 

When to swap the discs depends on the menu of the disc. Some demos have menus that stream data off the disc for full motion video and swapping the discs could result in a freeze or crash if you don't swap fast enough. My instructions above for the 11 volumes of Interactive CD Sampler avoid these issues. The swap methods given allow for relaxed timing. Using Vol 5 as an example, while the Crash demo is running and you can control the character you should be able to carefully grab the disc by the edge and center stopping it. Remove it in a short peroid of time so you don't hurt the motor. After you remove it you should be able to wait for the motor to stop trying to spin and then put your CD-R in. Then you can press Select to exit the demo which will cause the CD to spin up again and load the main menu. Then you can start the demo that was replaced with TonyHax.