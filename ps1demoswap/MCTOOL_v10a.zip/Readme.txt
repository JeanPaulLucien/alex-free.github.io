MCTOOL By: MottZilla
Version 1.0

This is a PS1 tool to install TonyHax or FreePSXBoot+TonyHax on your memory cards. It can remove the install of
FreePSXBoot from a memory card too. I created this tool so all you need to install/uninstall and use TonyHax is
the console itself and a way to boot a CD-R such as the swap trick. 

Your options include:

* Choose to Install FreePSXBoot+TonyHax to Memory Card
--* Choose Slot 1 or Slot 2 Install. Slot 2 Recommended.
--* Choose from multiple BIOS versions.

* Choose to Install TonyHax Game Saves to Memory Card
--* Choose from 5 different collections of TonyHax Save Game Exploits.

* Choose to Format Memory Card. Useful to remove FreePSXBoot Installs.

TonyHax Version 1.4.3

https://github.com/socram8888/tonyhax
https://github.com/brad-lin/FreePSXBoot/